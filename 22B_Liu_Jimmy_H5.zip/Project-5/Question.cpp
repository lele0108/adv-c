// Jimmy Liu
// Project 5
// 4 Nov. 2015
// XCode 7.0

#include <iostream>
#include <string>
#include <algorithm>
#include "Question.h"
using namespace std;

Question::Question(string a[], string q) {
	for (int i = 0; i < 4; i++) {
		answers[i] = a[i];
	}
	question = q;
}

int Question::getCorrect() {
	return correct;
}

string Question::getQuestion() {
	return question;
}

string* Question::getAnswers() {
	return answers;
}

void Question::randomize() {
	string answer = answers[correct];
	random_shuffle(&answers[0], &answers[3]);
	for (int i = 0; i < 4; i++) {
		if (answers[i] == answer)
			correct = i;
	}
}