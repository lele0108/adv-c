// Jimmy Liu
// Project 5
// 4 Nov. 2015
// XCode 7.0

#ifndef QUESTION
#define QUESTION
#include <iostream>
#include <string>
using namespace std;

class Question {
	private:
		string question;
		string answers[4];
		int correct;
	public:
		Question(string[], string);
		int getCorrect();
		string getQuestion();
		string* getAnswers();
		void randomize();
};
#endif